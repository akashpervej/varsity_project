-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 05, 2023 at 08:14 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `airline2`
--

-- --------------------------------------------------------

--
-- Table structure for table `airplane`
--

CREATE TABLE `airplane` (
  `ID` varchar(10) NOT NULL,
  `type` varchar(10) NOT NULL,
  `company` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `airplane`
--

INSERT INTO `airplane` (`ID`, `type`, `company`) VALUES
('01', 'B', 'US BANGLA'),
('03', 'B', 'Bangladesh Biman');

-- --------------------------------------------------------

--
-- Table structure for table `airport`
--

CREATE TABLE `airport` (
  `code` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `airport`
--

INSERT INTO `airport` (`code`, `name`, `city`, `state`, `country`) VALUES
('BARISHAL ', 'BARISHAL International Airport', 'Barishal', 'Barishal', 'BANGLADESH'),
('DHAKA', 'DHAKA INTERNATIONAL AIRPORT', 'DHAKA', 'DHAKA', 'BANGLADESH'),
('RAJSHAHI', 'Rajshahi International Airport', 'RAJSHAHI', 'RAJSHAHI', 'BANGLADESH'),
('SAYADPUR', 'SAYADPUR AIRPORT', 'Saidpur', 'Rangpur', 'BANGLADESH'),
('SYLHET', 'SHYLHET International Airport', 'SHYLHET ', 'SHYLHET ', 'BANGLADESH');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `ID` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `date` date NOT NULL,
  `flightno` varchar(10) NOT NULL,
  `username` varchar(45) NOT NULL,
  `classtype` varchar(20) NOT NULL,
  `paid` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`ID`, `time`, `date`, `flightno`, `username`, `classtype`, `paid`) VALUES
(69, '2023-06-12 10:00:41', '2023-12-11', 'DR', '1@admin.com', 'Economy', 1),
(70, '2023-06-13 02:05:43', '2023-12-11', 'DR', '1@admin.com', 'Economy', 1),
(71, '2023-06-14 02:51:32', '2023-12-11', 'DR', '1@admin.com', 'Economy', 1),
(72, '2023-06-14 03:01:22', '2023-12-11', 'DR', '1@admin.com', 'Economy', 1),
(73, '2023-06-15 12:41:04', '2023-12-07', 'SPR', '1@sabrina.com', 'Economy', 1),
(84, '2023-06-15 04:06:22', '2023-12-06', 'DR', '1@admin.com', 'Economy', 1),
(85, '2023-06-15 04:10:07', '2023-06-16', 'SPR', '1@admin.com', 'Economy', 1),
(86, '2023-06-15 04:10:07', '2023-06-20', 'RSP', '1@admin.com', 'Economy', 1),
(87, '2023-06-16 01:28:44', '2023-06-23', 'SPR', '1@user.com', 'Economy', 1),
(88, '2023-06-16 01:28:44', '2023-06-30', 'RSP', '1@user.com', 'Economy', 1),
(89, '2023-08-16 05:26:46', '2023-12-08', 'DR', '1@sabrina.com', 'Economy', 1),
(90, '2023-08-25 01:55:34', '2023-08-25', 'DR', '123', 'Economy', 1),
(91, '2023-08-25 01:56:14', '2023-08-30', 'RD', '123', 'Economy', 1),
(95, '2023-08-26 12:05:14', '2023-08-27', 'DR', '123', 'Economy', 1),
(96, '2023-08-26 12:05:14', '2023-08-30', 'RD', '123', 'Economy', 1);

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `number` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `capacity` int(11) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`number`, `name`, `capacity`, `price`) VALUES
('DR', 'Business', 50, 4500),
('DR', 'Economy', 50, 3200),
('DS', 'Business', 50, 3000),
('DS', 'Economy', 80, 5000),
('RB', 'Business', 15, 4000),
('RB', 'Economy', 50, 3600),
('RD', 'Economy', 50, 4500),
('RSP', 'Business', 40, 4000),
('RSP', 'Economy', 100, 3000),
('SPR', 'Business', 10, 4000),
('SPR', 'Economy', 100, 5000),
('SR', 'Business', 50, 5000),
('SR', 'Economy', 100, 5000);

-- --------------------------------------------------------

--
-- Table structure for table `flight`
--

CREATE TABLE `flight` (
  `number` varchar(20) NOT NULL,
  `airplane_id` varchar(10) NOT NULL,
  `departure` varchar(10) NOT NULL,
  `d_time` time NOT NULL,
  `arrival` varchar(10) NOT NULL,
  `a_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `flight`
--

INSERT INTO `flight` (`number`, `airplane_id`, `departure`, `d_time`, `arrival`, `a_time`) VALUES
('DHA', '01', 'DHAKA', '18:35:00', 'RAJSHAHI', '21:00:00'),
('DR', '03', 'DHAKA', '18:35:00', 'RAJSHAHI', '21:00:00'),
('DS', '03', 'DHAKA', '17:00:00', 'SYLHET', '21:00:00'),
('RB', '03', 'RAJSHAHI', '14:35:00', 'BARISHAL ', '17:30:00'),
('RD', '03', 'RAJSHAHI', '18:35:00', 'DHAKA', '21:00:00'),
('RSP', '03', 'RAJSHAHI', '07:35:00', 'SAYADPUR', '10:30:00'),
('SPR', '01', 'SAYADPUR', '19:30:00', 'RAJSHAHI', '22:00:00'),
('SR', '01', 'SYLHET', '13:40:00', 'RAJSHAHI', '19:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `passanger`
--

CREATE TABLE `passanger` (
  `username` varchar(30) NOT NULL,
  `firstname` varchar(45) DEFAULT NULL,
  `middlename` varchar(45) DEFAULT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `cellphone` varchar(15) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `passanger`
--

INSERT INTO `passanger` (`username`, `firstname`, `middlename`, `lastname`, `email`, `cellphone`, `gender`, `birthday`, `password`) VALUES
('123', 'MD.AKASH', 'Sjb', 'PERVEJ', 'akashmh10@gmail', '01785022895', 'Male', '1998-12-11', '123'),
('1@admin.com', 'AKASH', '', 'PERVEJ', 'akashmh9@gmail.com', '01785022895', 'Male', '1996-12-11', 'Admin1'),
('1@sabrina.com', 'Sabrina', 'Shushum', 'Dristy', '1@gmail.com', '123456789', 'Female', '1998-12-12', 'S12345'),
('1@user.com', 'USER', 'AK', 'SB', 'aksb@email.com', '01785022895', 'Male', '1998-12-22', 'User12'),
('2@aa.com', 'ds', 'hf', 'hf', 'fjfgjfjfuj@email.com', '5346345', 'Male', '1996-01-12', 'Admin1'),
('admin02', 'Admin', 'A', 'B', 'abc@gmail.com', '4564858', 'Male', '1997-12-11', 'Admin2'),
('admin@admin.com', 'NURUL', '', 'ISLAM', 'akashmh10@gmail.com', '01850801111', 'Male', '1996-12-11', 'Aadmin1'),
('as', 'ausu', 'hyad', 'ohadh', 'admin2@gmail.com', '0654651', 'Male', '0192-11-01', 'Ad1234'),
('assq', 'Asj', 'Sjb', 'Djb', 'akash@email.com', '05416194', 'Male', '1998-11-11', 'Admin1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `airplane`
--
ALTER TABLE `airplane`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `airport`
--
ALTER TABLE `airport`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`ID`,`flightno`),
  ADD KEY `username_idx` (`username`),
  ADD KEY `classname_idx` (`classtype`),
  ADD KEY `flightno_idx` (`flightno`,`classtype`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`number`,`name`),
  ADD KEY `number_idx` (`number`);

--
-- Indexes for table `flight`
--
ALTER TABLE `flight`
  ADD PRIMARY KEY (`number`),
  ADD KEY `code_idx` (`departure`,`arrival`),
  ADD KEY `airplaneid_idx` (`airplane_id`),
  ADD KEY `arrival_idx` (`arrival`);

--
-- Indexes for table `passanger`
--
ALTER TABLE `passanger`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `flightno` FOREIGN KEY (`flightno`,`classtype`) REFERENCES `class` (`number`, `name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `username` FOREIGN KEY (`username`) REFERENCES `passanger` (`username`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `class`
--
ALTER TABLE `class`
  ADD CONSTRAINT `number` FOREIGN KEY (`number`) REFERENCES `flight` (`number`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `flight`
--
ALTER TABLE `flight`
  ADD CONSTRAINT `airplaneid` FOREIGN KEY (`airplane_id`) REFERENCES `airplane` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `arrival` FOREIGN KEY (`arrival`) REFERENCES `airport` (`code`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `departure` FOREIGN KEY (`departure`) REFERENCES `airport` (`code`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
