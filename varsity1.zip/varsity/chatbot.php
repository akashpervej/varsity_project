<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sample Chatbot</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        /* Styling for the messenger icon */
        #messenger-icon {
            position: fixed;
            bottom: 20px;
            right: 20px;
            font-size: 24px;
            background-color: #007bff;
            color: #fff;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            text-align: center;
            line-height: 50px;
            cursor: pointer;
        }

        /* Styling for chatbot container */
        #chatbot-container {
            position: fixed;
            bottom: 80px;
            right: 20px;
            width: 350px;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        #chat-header {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        #chat-body {
            padding: 10px;
            max-height: 300px;
            overflow-y: auto;
        }

        .message {
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
        }

        .user-message {
            background-color: #f0f0f0;
            color: #000;
        }

        .bot-message {
            background-color: #007bff;
            color: #fff;
        }

        /* Styling for user and chatbot labels */
        .message-label {
            font-weight: bold;
            margin-right: 5px;
        }

        /* Styling for input field and send button */
        #user-input-container {
            display: flex;
            margin-top: 10px;
        }

        #user-input {
            flex: 1;
            padding: 10px;
            border: none;
            border-top: 1px solid #ccc;
            border-radius: 5px 0 0 5px;
        }

        #send-button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 0 5px 5px 0;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Messenger icon -->
    <div id="messenger-icon">
        <i class="fas fa-comments"></i>
    </div>

    <!-- Initially hidden chatbot container -->
    <div id="chatbot-container" style="display: none;">
        <div id="chat-header">
            <h3>Chatbot</h3>
        </div>
        <div id="chat-body">
            <div class="message bot-message">
                <span class="message-label">Chatbot:</span> Hello! How can I help you?
            </div>
        </div>
        <div id="user-input-container">
            <input type="text" id="user-input" placeholder="Type your message...">
            <button id="send-button"><i class="fas fa-paper-plane"></i></button>
        </div>
    </div>

    <script>
        const userInput = document.getElementById('user-input');
        const sendButton = document.getElementById('send-button');
        const chatBody = document.getElementById('chat-body');

        sendButton.addEventListener('click', sendMessage);
        userInput.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                sendMessage();
            }
        });

        function sendMessage() {
            const userMessage = userInput.value;
            if (userMessage.trim() === '') return;

            appendUserMessage(userMessage);

            const botResponse = processUserMessage(userMessage);

            appendBotMessage(botResponse);

            userInput.value = '';
            chatBody.scrollTop = chatBody.scrollHeight;
        }

        function appendUserMessage(message) {
            const messageContainer = document.createElement('div');
            messageContainer.classList.add('message', 'user-message');
            messageContainer.innerHTML = `<span class="message-label">You:</span> ${message}`;
            chatBody.appendChild(messageContainer);
        }

        function appendBotMessage(message) {
            const messageContainer = document.createElement('div');
            messageContainer.classList.add('message', 'bot-message');
            messageContainer.innerHTML = `<span class="message-label">Chatbot:</span> ${message}`;
            chatBody.appendChild(messageContainer);
        }

        function processUserMessage(userMessage) {
            // Convert user message to lowercase for case-insensitive matching
            const lowercaseMessage = userMessage.toLowerCase();

            // Simple demo response based on user input
            if (lowercaseMessage === 'hello') {
                return "Hello! How can I help you?";
            }

            // Add more logic and responses as needed
            return "I'm a demo chatbot, and I'm here to assist you.";
        }

        let chatbotVisible = false;

        document.getElementById('messenger-icon').addEventListener('click', () => {
            const chatbotContainer = document.getElementById('chatbot-container');
            chatbotVisible = !chatbotVisible;

            if (chatbotVisible) {
                chatbotContainer.style.display = 'block';
            } else {
                chatbotContainer.style.display = 'none';
            }
        });



        const bookingData = [
    { id: 1, name: 'John Doe', flight: 'AA123', date: '2023-09-15', destination: 'New York' },
    { id: 2, name: 'Jane Smith', flight: 'UA456', date: '2023-09-20', destination: 'Los Angeles' },
    { id: 3, name: 'Alice Johnson', flight: 'DL789', date: '2023-09-25', destination: 'Chicago' },
];

function processUserMessage(userMessage) {
    const lowercaseMessage = userMessage.toLowerCase();

    if (lowercaseMessage.includes('booking')) {
        const query = lowercaseMessage.split('booking')[1].trim();
        const matchingBookings = findMatchingBookings(query);

        if (matchingBookings.length > 0) {
            return formatBookingList(matchingBookings);
        } else {
            return "I couldn't find any matching bookings.";
        }
    }

    // Add more logic and responses as needed
    return "I'm a demo chatbot, and I'm here to assist you.";
}

function findMatchingBookings(query) {
    // Filter booking data based on the query (you can implement more complex filtering logic)
    return bookingData.filter(booking =>
        booking.name.toLowerCase().includes(query) ||
        booking.flight.toLowerCase().includes(query) ||
        booking.date.includes(query) ||
        booking.destination.toLowerCase().includes(query)
    );
}

function formatBookingList(bookings) {
    // Format the list of matching bookings
    let result = "Here are the matching bookings:\n";

    for (const booking of bookings) {
        result += `Booking ID: ${booking.id}\n`;
        result += `Name: ${booking.name}\n`;
        result += `Flight: ${booking.flight}\n`;
        result += `Date: ${booking.date}\n`;
        result += `Destination: ${booking.destination}\n\n`;
    }

    return result;
}
    </script>
</body>
</html>
